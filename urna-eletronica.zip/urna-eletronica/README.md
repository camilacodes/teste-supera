1- Frontend

Construa uma tela simulando uma urna eletrônica conforme exemplo abaixo utilizando
Javascript (podendo usar framework ou Javascript puro) para realizar as validações. A
urna deverá ser capaz de receber apenas dois números, ao digitar o número deverá
trazer a foto do candidato e o nome do candidato (45 – Pedrinho ou 22 – Zezinho). Ao
clicar no botão verde (Confirma) a tela irá apresentar uma mensagem que o voto foi
realizado com sucesso.
Caso seja apertado o botão vermelho (Corrige) a urna deverá apagar os números que
foram digitados pelo usuário.
Caso seja apertado o botão cinza (Votar em Branco) a urna deverá apresentar uma
mensagem que o voto foi computado em branco.
Funcionalidades que serão avaliadas:

- Layout (deverá ser o mais próximo de urna eletrônica possível).
- Validações utilizando Javascript.
- Organização do código.
- Funcionalidades da urna.
- Print com evidência do teste.


3- Sql

- Dado a estrutura da tabela Funcionários acima, construa uma query que traga todos os
funcionários com salário menor que 5000.
- Atualize o salário do funcionário para 2000 caso o nome dele(a) comece com a Letra “A”.