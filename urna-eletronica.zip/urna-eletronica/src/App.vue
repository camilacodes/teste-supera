<template>
  <div id="app">
    <div class="urna">
      <tela
        :tela="tela"
        :numeroVoto="numeroVoto"
        :quantidadeNumeros="quantidadeNumeros"
        :candidato="candidato"
      />

      <Teclado
        :adicionarNumero="adicionarNumero"
        :corrigir="corrigir"
        :confirmar="confirmar"
      />
    </div>
  </div>
</template>

<script>
import "@/css/style.css";
import Teclado from "@/components/Teclado";
import Tela from "@/components/Tela";

export default {
  name: "App",
  components: {
    Teclado,
    Tela,
  },

  methods: {
    adicionarNumero(numero) {
      if (this.numeroVoto.length == this.quantidadeNumeros) {
        return false;
      }

      this.numeroVoto += "" + numero;
      this.verificarCandidato();
    },

    verificarCandidato() {
      if (this.numeroVoto.length < this.quantidadeNumeros) {
        return false;
      }
      if (this.candidatos[this.tela][this.numeroVoto]) {
        this.candidato = this.candidatos[this.tela][this.numeroVoto];
        return true;
      }

      // voto em branco
      this.candidato = {
        nome: "Voto Branco",
        partido: "Voto Branco",
        imagem: "",
      };
    },
    corrigir() {
      this.limpar();
    },
    limpar() {
      this.candidato = {}
      this.numeroVoto = ''
    },
    confirmar(){
      if(this.numeroVoto.length < this.quantidadeNumeros){
      return false;
      }

      return this.telaFinal();
    },

    telaFinal(){
      if(this.tela == 'presidente')
        this.tela = 'presidente'
        this.tela = 'fim';
      }
       
},
  data() {
    return {
      tela: "presidente",
      numeroVoto: "",
      quantidadeNumeros: 2,
      candidato: {},
      candidatos: {
        presidente: {
          45: {
            nome: "Pedrinho",
            partido: "Partido 45",
            imagem: "https://user-images.githubusercontent.com/66393807/159373293-e1f61457-bf07-49c2-948c-b6068819d9df.jpg"
          },
          55: {
            nome: "Zezinho",
            partido: "Partido 55",
            imagem: "https://user-images.githubusercontent.com/66393807/159373352-07303992-78de-4a16-8f05-cd3175912fef.jpg",
          
          },
        },
      },
    };
  },
  }
  
</script>

<style>
#app {
  background-color: #333333;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.urna {
  width: 1000px;
  height: 500px;
  background-color: #dcdde1;
  padding: 30px;
  display: flex;
}
</style>
