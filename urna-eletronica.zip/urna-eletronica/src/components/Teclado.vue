<template>
  <div class="urna-teclado">
    <div class="teclado-numerico">
      <div class="teclado-numerico-botoes">
        <button v-on:click="adicionarNumero(1)">1</button>
        <button v-on:click="adicionarNumero(2)">2</button>
        <button v-on:click="adicionarNumero(3)">3</button>
      </div>

      <div class="teclado-numerico-botoes">
        <button v-on:click="adicionarNumero(4)">4</button>
        <button v-on:click="adicionarNumero(5)">5</button>
        <button v-on:click="adicionarNumero(6)">6</button>
      </div>

      <div class="teclado-numerico-botoes">
        <button v-on:click="adicionarNumero(7)">7</button>
        <button v-on:click="adicionarNumero(8)">8</button>
        <button v-on:click="adicionarNumero(9)">9</button>
      </div>

      <div class="teclado-numerico-botoes">
        <button v-on:click="adicionarNumero(0)">0</button>
      </div>
    </div>

    <div class="urna-botoes">
      <button class="btn-branco">BRANCO</button>
      <button class="btn-corrige"  v-on:click="corrigir()">CORRIGE</button>
      <button class="btn-confirma" v-on:click="confirmar()">CONFIRMA</button>
    </div>
  </div>
</template>
<script>
export default {
  name: "UrnaTeclado",
  props: {
    adicionarNumero: Function,
    corrigir: Function,
    confirmar: Function
  },
};
</script>

<style>
.urna-teclado {
  width: 40%;
  height: 100%;
  background: black;
  padding: 20px;
}

.teclado-numerico {
  width: 100%;
}

.teclado-numerico-botoes {
  display: flex;
  justify-content: space-around;
  margin-bottom: 20px;
}

.teclado-numerico-botoes button {
  background-color: #2f3640;
  color: rgb(0, 0, 0);
  font-size: 30px;
  border-radius: 5px;
  width: 80px;
  height: 50px;
}

.urna-botoes {
  width: 100%;
  display: flex;
  justify-content: space-around;
}

.urna-botoes button {
  width: 30%;
  height: 50px;
  color: black;
  font-size: 15px;
  border-radius: 5px;
}

.btn-branco {
  background-color: white;
}

.btn-corrige {
  background-color: orange;
}

.btn-confirma {
  background-color: green;
}
</style>
