<template>
  <div v-if="tela != 'resposta'" class="urna-tela">
    <div class="voto">
      <div class="urna-tela-texto">
        <div class="urna-tela-candidato">Candidato:</div>
        <div class="urna-tela-tipo">{{ tela }}</div>
      </div>

      <div class="numero-candidato">
        Número:
        <div
          class="tela-voto"
          v-for="(value, key) in numeroVoto.padEnd(quantidadeNumeros, ' ')"
          :key="key"
        >
          {{ value }}
        </div>
      </div>

      <div class="candidato-info">
        Nome: {{ candidato.nome ? candidato.nome : "" }}
      </div>

      <div class="candidato-info">
        Partido: {{ candidato.partido ? candidato.partido : "" }}
      </div>

      <div v-if="candidato.imagem" class="urna-tela-img">
        <img :src="candidato.imagem"/>
      </div>


    </div>

    <div v-if="tela == 'fim'" class="tela-final">
        fim
    </div>
  </div>
</template>

<script>
export default {
  name: "UrnaTela",
  props: {
    tela: String,
    numeroVoto: String,
    quantidadeNumeros: Number,
    candidato: Object,
  },
};
</script>

<style>
.urna-tela {
  width: 60%;
  height: 100%;
  background-color: white;
}

.urna-tela-texto {
  font-size: 15px;
}
.urna-tela-tipo {
  font-size: 30px;
  margin: 20px 0;
  font-style: bold;
}

.numero-candidato {
  display: flex;
  align-items: center;
  color: black;
}

.tela-voto {
  width: 45px;
  height: 55px;
  border: 1px solid black;
  margin-left: 10px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 30px;
}

.candidato.info {
  margin-top: 20px;
}

.urna-tela-img img {
  width: 150px;
  height: 150px;
  border: 2px solid color grey;
}

.tela-final{
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 100px;
}
</style>
